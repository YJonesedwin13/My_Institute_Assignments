use assignment;
####SHEET 3#########
####Question No:1###########

select * from orders;

delimiter //
create procedure order_sts(in y int unsigned, in m int unsigned)
begin 
select ordernumber, orderdate, status from orders where year(orderdate) = y and month(orderdate) = m;
end //
delimiter ;

call order_sts(2004, 3);

############################     Question No:2.a       ######################################################

select * from payments;

delimiter //
create function pr_sts(customer_no int) returns varchar(20)
deterministic
begin
		declare stat varchar(20);
        declare total numeric;
        set total = (select sum(amount) from payments where customernumber = customer_no);
        
        if total > 50000 then set stat = 'platinum';
        elseif (total >=25000 and total <= 50000) then set stat = 'gold';
        elseif total < 25000 then set stat = 'silver';
        end if;
        return (stat);
 end //
 delimiter ;
#######################     Question No:2.b   #######################

select pr_sts(112);

select * from customers;
select * from payments;

alter table customers add column pr_sts varchar(20);

update customers c
set pr_sts = (select pr_sts(customernumber) from payments p where p.customernumber = c.customernumber
                       group by p.customernumber);
                       
select customernumber, customername, pr_sts(customernumber) from customers;                       

######################   Question No:3  ############################

select * from movies;
select * from rentals;

##############Del on cascade

delimiter //
create trigger del_movies after delete on movies for each row
begin
    delete from rentals
    where movieid = old.id;
end //
delimiter ;

delete from movies where id = 4;
delete from rentals where memid = 4;

select * from movies;
select * from rentals;

########## Update on cascade

delimiter //
create trigger update_movies after update on movies for each row
begin
    update rentals
    set movieid = new.id
    where movieid = old.id;
end //
delimiter ;

update movies set id = 7 where id = 8;

select * from movies;

#################################     Question No:4    ##################################


select * from employee;

select fname from (select fname, salary,dense_rank() over (order by salary desc) as salary_rank from employee) subquery where salary_rank = 1;


##############################          Question No:5              ################################

select fname,lname,salary,dense_rank() over (order by salary desc) as salary_rank  from employee;




