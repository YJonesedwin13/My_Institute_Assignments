############    Question No:1       #################

select * from employee;
select * from employee where deptno=10 and salary >= 3000;####select all employees in department 10 whose salary is greater than 3000. 

#################  Question No:2        #############################

select * from students;
SELECT *,
CASE
	WHEN Marks>=80 THEN 'Distinction'
    when Marks>=60 and Marks<80 then "First class"
    WHEN Marks>=50 AND Marks<60 THEN 'First class'
    WHEN Marks>=50 AND Marks<40 THEN 'Second class'
    ELSE 'F'
END AS Grade
FROM students;################grading of students based on the marks they have obtained is done as follows
##########     Question No:2a                #####################
select count(*) from students where marks between 50 and 80;
##################     Question No:2b                  ########################################
select count(*) from students where marks between 80 and 100;

####################   Question No:3        ###############################

select * from station;
select distinct city from station where (id %2)=0;

####################   Question No:4        ################################

select count(city) - count(distinct city) from station;

####################    Question No: 5. a.b.c.d          ##############################
select distinct city from station where city like "A%" OR city like "E%" OR city like "I%" OR city like "O%" OR city like "U%";

select distinct city from station where (city like "A%" OR city like "E%" OR city like "I%" OR city like "O%" OR city like "U%") AND (city like "%A"
OR city like "%E" or city like "%I" or city like "%O" or city like "%U");

select distinct city from station where city NOT like "A%" AND city NOT like "E%" AND city NOT like "I%" AND city NOT like "O%" AND city NOT like "U%";

select distinct city from station where (city NOT like "A%" AND city NOT like "E%" AND city NOT like "I%" AND city NOT like "O%" AND city NOT like "U%") AND (city NOT like "%A"
AND city NOT like "%E" AND city NOT like "%I" AND city NOT like "%O" AND city NOT like "%U");

###############################   Question No:6         ###################################################################################################

SELECT * FROM EMP;
SELECT * FROM EMP WHERE SALARY>2000 AND HIRE_DATE>= DATE_SUB(CURRENT_DATE,INTERVAL 36 MONTH) ORDER BY EMP_NO DESC;

#######################################   Question No: 7           ############################################################################

SELECT* FROM EMPLOYEE;
SELECT DEPTNO,SUM(SALARY) FROM EMPLOYEE GROUP BY DEPTNO;

#####################   Question No: 8        #####################################
SELECT* FROM CITY;
SELECT COUNT(POPULATION) FROM CITY WHERE POPULATION>100000;

#########################     Question No: 9                #########################################

SELECT SUM(POPULATION) FROM CITY WHERE DISTRICT ="CALIFORNIA";

#########################     Question No: 10           #######################################

SELECT COUNTRYCODE,AVG(POPULATION) FROM CITY WHERE COUNTRYCODE IN ('JPN','USA','NLD') GROUP BY COUNTRYCODE;

####################################     Question No:11          ##########################################################

SELECT* FROM ORDERS;
SELECT* FROM CUSTOMERS;

select orders.ordernumber, orders.status, customers.customernumber, customers.customername, orders.comments
from orders join customers on orders.customernumber = customers.customernumber where orders.status = 'Disputed';

#######################################################################################

